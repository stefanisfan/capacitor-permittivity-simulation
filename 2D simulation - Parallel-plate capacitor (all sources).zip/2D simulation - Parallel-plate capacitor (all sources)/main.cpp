#include <iostream>
#include <fstream>

using namespace std;

#define dimaxx 1000
#define dimaxy 1000

double eps[dimaxx+1][dimaxy+1], V[dimaxx+1][dimaxy+1], V_in[dimaxx+1][dimaxy+1],
       Ex[dimaxx+1][dimaxy+1], Ey[dimaxx+1][dimaxy+1];
int marc[dimaxx+1][dimaxy+1];

void exporta_eps(int nx, int ny, double hx, double hy)
{
    int i, j;
    ofstream fe("eps.txt");
    for(i=1;i<=nx;i++)
        for(j=1;j<=ny;j++)
            fe<<i*hx-hx/2<<" "<<j*hy-hy/2<<" "<<eps[i][j]<<endl;
    fe.close();
}

void exporta_marc(int nx, int ny, double hx, double hy)
{
    int i, j;
    ofstream fe("marc.txt");
    for(i=0;i<=nx;i++)
        for(j=0;j<=ny;j++)
            fe<<i*hx<<" "<<j*hy<<" "<<marc[i][j]<<endl;
    fe.close();
}

void exporta_V(int nx, int ny, double hx, double hy)
{
    int i, j;
    ofstream fe("V.txt");
    for(i=0;i<=nx;i++)
        for(j=0;j<=ny;j++)
            fe<<i*hx<<" "<<j*hy<<" "<<V[i][j]<<endl;
    fe.close();
}

double err(int nx, int ny)
{
    double sum, aux;
    int i, j;
    sum=0;
    for(i=0;i<=nx;i++)
        for(j=0;j<=ny;j++)
        {
            aux=V[i][j]-V_in[i][j];
            if(aux<=0.0)   aux=-aux;
            sum=sum+aux;
        }
    sum=sum;
    return sum;
}

void gaseste_V(int nx, int ny, double hx, double hy, double Vplus, double Vminus)
{
    int kapa, i, j;
    double eps1, eps2, eps3, eps4, aux1, aux2, aux3, aux4, ERR;
    for(kapa=1;kapa<=100000;kapa++) /// procedura iterativa care utilizeaza maximum 100K pasi
    {
        for(i=1;i<nx;i++)
            for(j=1;j<ny;j++)
            {
                eps1=(eps[i][j]+eps[i+1][j])/2;
                eps2=(eps[i][j]+eps[i][j+1])/2;
                eps3=(eps[i+1][j]+eps[i+1][j+1])/2;
                eps4=(eps[i][j+1]+eps[i+1][j+1])/2;
                aux1=eps1/(hy*hy);
                aux2=eps2/(hx*hx);
                aux3=eps3/(hx*hx);
                aux4=eps4/(hy*hy);
                V[i][j]=aux1*V_in[i][j-1]+aux2*V_in[i-1][j]+aux3*V_in[i+1][j]+aux4*V_in[i][j+1];
                V[i][j]=V[i][j]/(aux1+aux2+aux3+aux4);
                if(marc[i][j]==2)    V[i][j]=Vminus; /// impunerea conditiilor la limita
                if(marc[i][j]==3)    V[i][j]=Vplus; /// impunerea conditiilor la limita
            }
        if(kapa%100==0)
        {
            ERR=err(nx, ny);
            //cout<<kapa<<" "<<ERR<<endl;
            if(ERR<=1.0e-10)    break; /// procedura sa opreste cand eroarea este mai mica decat 10^(-10)

        }
        for(i=1;i<nx;i++)
            for(j=1;j<ny;j++)
            {
                V_in[i][j]=V[i][j];
            }
    }
}

exporta_sys(int nx, int ny, double hx, double hy)
{
    int i, j;
    ofstream fe("sys.txt");

}

int main()
{

    int nx, ny, i, j, kapa, i1, i2, j1, j2;
    double Lx, Ly, l, d, hx, hy, epsd, Vplus, Vminus;

    nx=100; /// numarul de celule pe Ox
    ny=100; /// numarul de celule pe Oy

    Lx=0.1; /// in metri
    Ly=0.1; /// in metri
    l=0.02; /// in metri
    d=0.01; /// in metri
    epsd=4;

    hx=Lx/nx; /// pasul de discretizare pe Ox
    hy=Ly/ny; /// pasul de discretizare pe Oy

    i1=(int)(0.5*(Lx-l)/hx);
    i2=(int)(0.5*(Lx+l)/hx);
    j1=(int)(0.5*(Ly-d)/hy);
    j2=(int)(0.5*(Ly+d)/hy);

    for(i=1;i<=nx;i++)
        for(j=1;j<=ny;j++)
            eps[i][j]=1.0;
    for(i=i1+1;i<=i2;i++)
        for(j=j1+1;j<=j2;j++)
            eps[i][j]=epsd;


    for(i=0;i<=nx;i++)
        for(j=0;j<=ny;j++)
        {
            marc[i][j]=0;
            if(i==0 || i==nx || j==0 || j==ny)   marc[i][j]=1;
        }
    for(i=i1;i<=i2;i++)
    {
        marc[i][j1]=2;
        marc[i][j2]=3;
    }

    ofstream fe("sys.txt");
    for(i=0;i<=nx;i++)
        fe<<i*hx<<" "<<0*hy<<" "<<marc[i][0]<<endl;
    for(j=1;j<=ny;j++)
        fe<<nx*hx<<" "<<j*hy<<" "<<marc[nx][j]<<endl;
    for(i=nx-1;i>=0;i--)
        fe<<i*hx<<" "<<ny*hy<<" "<<marc[i][ny]<<endl;
    for(j=ny-1;j>=0;j--)
        fe<<0*hx<<" "<<j*hy<<" "<<marc[0][j]<<endl;
    fe<<endl;
    for(i=i1;i<=i2;i++)
        fe<<i*hx<<" "<<j1*hy<<" "<<marc[i][j1]<<endl;
    for(j=j1+1;j<=j2;j++)
        fe<<i2*hx<<" "<<j*hy<<" "<<marc[i2][j]<<endl;
    for(i=i2-1;i>=i1;i--)
        fe<<i*hx<<" "<<j2*hy<<" "<<marc[i][j2]<<endl;
    for(j=j2-1;j>=j1;j--)
        fe<<i1*hx<<" "<<j*hy<<" "<<marc[i1][j]<<endl;
    fe.close();

    Vplus=10.0;
    Vminus=-10.0;
    gaseste_V(nx, ny, hx, hy, Vplus, Vminus);
    exporta_V(nx, ny, hx, hy);

    double Wt, Exx, Eyy, Em;
    Wt=0;
    for(i=1;i<=nx;i++)
        for(j=1;j<=ny;j++)
        {
            Exx=(V[i+1][j+1]+V[i+1][j]-V[i][j+1]-V[i][j])/(2*hx);
            Eyy=(V[i][j+1]+V[i+1][j+1]-V[i][j]-V[i+1][j])/(2*hy);
            Em=Exx*Exx+Eyy*Eyy;
            Wt+=eps[i][j]*Em*hx*hy/2.0;
        }

    cout<<epsd<<"  "<<Wt<<endl;

    return 0;
}
